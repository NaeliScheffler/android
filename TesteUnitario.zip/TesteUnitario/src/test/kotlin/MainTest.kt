import org.junit.jupiter.api.*
import kotlin.test.fail

class MainTest {

    @Test
    fun testeIfElse(){
        Assertions.assertTrue(maiorDeIdade(29))
    }

    @Test
    fun provocacao() {
        //não tem o porque fazer se for dessa forma
        Assertions.assertNotNull(countXO("jhduehfurhe"))
        Assertions.assertNotNull(countXO("xxo"))
    }

    @Test
    @DisplayName("Teste metodo xoxo")
    fun testCountXO() {
        Assertions.assertTrue(countXO("xxoo"))
        Assertions.assertTrue(countXO("xXoo"))

        Assertions.assertAll(
            { Assertions.assertTrue(countXO("xxoo")) },
            { Assertions.assertTrue(countXO("xxoO")) }
        )

        @Test
        @Disabled
        fun naoImplementado() {

        }

        @Test
        fun vaiFalhar() {
            fail("Não posso terminar os testes sem esse método")
        }

    }

    @Test
    fun assumptions() {
        Assumptions.assumeTrue(countXO("xxo"))

        Assertions.assertTrue(abc())
    }

    @Test
    fun exception() {
        assertThrows<NullPointerException> { abc() }
    }
}